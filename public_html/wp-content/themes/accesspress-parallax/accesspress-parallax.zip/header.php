<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package accesspress_parallax
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.js"></script>
<![endif]-->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="loader" style="background-color: black; z-index: 999999; position: fixed; top: 0; left: 0; height: 100vh; width: 100vw;">
	<center>
	<div class="loader"></div>
	</center>
</div>
<div id="page" class="hfeed site">
	<header id="masthead" class="<?php echo of_get_option('header_layout'); ?>">
		<div class="mid-content clearfix">
        
        <div class="flex-box">
		<div id="site-logo">
		<?php if ( get_header_image() ) : ?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<img src="<?php header_image(); ?>" alt="<?php bloginfo( 'name' ); ?>">
		</a>
		<?php else:?>
			<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
			<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
		<?php endif; ?>
		</div>

		<nav id="site-navigation" class="main-navigation">
        
		<div class="menu-toggle"><?php _e( 'Menu', 'accesspress-parallax' ); ?></div>
					
			<?php 
			$sections = of_get_option('parallax_section');
			if((of_get_option('enable_parallax') == 1 && of_get_option('enable_parallax_nav') == 1) || (is_page_template('home-page.php') && of_get_option('enable_parallax_nav') == 1)):
			?>
			<ul class="nav single-page-nav">
				<?php
				$home_text = of_get_option('home_text');
				if(of_get_option('show_slider')== "yes" && !empty($home_text)) : 
					if(function_exists('pll__')){
						$home_text = pll__($home_text);
					}
					?>
					<li class="current"><a href="<?php echo esc_url( home_url( '/' ) ); ?>#main-slider"><?php echo esc_html($home_text); ?></a></li>
				<?php endif;
				
				if(!empty($sections)):
				foreach ($sections as $single_sections): 
					if($single_sections['layout'] != "action_template" && $single_sections['layout'] != "blank_template" && $single_sections['layout'] != "googlemap_template" && !empty($single_sections['page'])) :
						if(function_exists('pll_get_post')){
							$title_id = pll_get_post($single_sections['page']);
							$title = empty($title_id) ? get_the_title($single_sections['page']) : get_the_title($title_id);
						}else{
							$title = get_the_title($single_sections['page']); 
						}	
						?>
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>#section-<?php echo $single_sections['page']; ?>"><?php echo esc_html($title); ?></a></li>
					<?php 
					endif;
				endforeach; 
				endif; ?>
			</ul>
			<?php	
			else: 
				wp_nav_menu( array( 
				'theme_location' => 'primary' , 
				'container'      => false
				) );
			endif; ?>
		
		</nav><!-- #site-navigation -->
        </div>
		</div>


		<?php 
		if(of_get_option('show_social') == 1):
			do_action('accesspress_social');
		endif; ?>
	</header><!-- #masthead -->

	<?php 
	$accesspress_show_slider = of_get_option('show_slider') ;
	$content_class = "";
	if(empty($accesspress_show_slider) || $accesspress_show_slider == "no"):
		$content_class = "no-slider";
	endif;
	?>
	<div id="content" class="site-content <?php echo esc_attr($content_class); ?>">
	<?php 
	if(is_home() || is_front_page()) :
		do_action('accesspress_bxslider'); 
	endif;
	?>